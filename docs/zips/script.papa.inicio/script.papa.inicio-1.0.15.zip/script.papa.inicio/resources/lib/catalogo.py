# -*- coding: utf-8 -*-
"""El catálogo de Palantir para la búsqueda de la skin (la lupa).

Pedirle la búsqueda a Palantir tarda: arranca en ~4,5 s cada vez (su código está ofuscado) y su consulta compara
título a título en Python. Aquí se lee su base directamente (SQLite, solo lectura). Palantir cerró (17/11/2026): la lupa
busca ahora en TMDb (lupa.py) y este catálogo queda de reserva; al pulsar una ficha, el asistente la busca en Balandro
y la reproduce (fichas.py).
Puro: las rutas llegan de fuera.
"""
import base64
import os
import sqlite3
import unicodedata
from urllib import parse

from resources.lib.fichas import play_url, serie_url

PALANTIR = 'plugin://plugin.video.palantir3/?'
IMAGES = 'https://image.tmdb.org/t/p/'
YOUTUBE = 'plugin://plugin.video.youtube/play/?video_id=%s'

# Lo mismo que busca "Por título" de Palantir (sus vistas v_pelis_Pelicula y v_series_General): esas categorías y
# solo lo que tiene enlaces. tipo → (tabla, tabla de enlaces, categorías)
KINDS = {'peliculas': ('pelis', 'enlaces_pelis', ('Película',)),
         'series': ('series', 'enlaces_series', ('General', 'Retro', 'Reality'))}
ALL = 'todo'  # películas y series en una sola llamada: la búsqueda de AF3 las pone en una fila por tipo
LIMIT = 60  # por fila
MIN_CHARS = 2  # con una letra saldría medio catálogo mientras se escribe
FIELDS = ('tmdb', 'titulo', 'fecha', 'plot', 'poster', 'fondo', 'mpaa', 'genero', 'trailer', 'clearlogo', 'rating')


def _fold(ch):
    """Una letra como la deja map_string de Palantir: base sin acento y en mayúscula; nada si es signo."""
    if ch == ' ':
        return ' '
    if ord(ch) > 0xFF:
        return ''
    base = unicodedata.normalize('NFKD', ch)[0]
    return base.upper() if base.isascii() and base.isalnum() else ''


def normalize(text):
    """'Señor O'Brien' → 'SENOR OBRIEN', como compara Palantir en su búsqueda (iREGEXP con map_string)."""
    return ''.join(_fold(ch) for ch in (text or '').strip()).strip()


def p3_encode(text):
    """El p3b64encode de Palantir: base64 con las dos partes del texto al revés."""
    value = base64.b64encode(text.encode('utf-8'))
    cut = int(len(value) / 4)
    value = value.replace(b'=', b'')
    return parse.quote(value[:cut][::-1] + value[cut:][::-1])


def p3_decode(value):
    value = parse.unquote(value).encode('utf-8').replace(b'?', b'')
    pad = (4 - len(value) % 4) % 4
    cut = int((len(value) + pad) / 4)
    return base64.b64decode(value[:cut][::-1] + value[cut:][::-1] + b'=' * pad).decode('utf-8')


def p3_url(fields):
    """La dirección de una ficha de Palantir (su P3Item.tourl: el dict con las claves ordenadas)."""
    text = '{%s}' % ', '.join('"%s": %r' % (key, fields[key]) for key in sorted(fields))
    return PALANTIR + p3_encode(text)


def _image(size, path):
    if not path:
        return ''
    if path.lower().startswith('http'):
        return path
    return IMAGES + size + (path if path.startswith('/') else '/' + path)


def _rating(value):
    try:
        return float(str(value or '').split('/')[0])
    except ValueError:
        return None


def _title(row):
    return (row.get('titulo') or '').replace('\\n', '').strip()


def palantir_path(kind, row):
    """La ficha de Palantir tal como la pone él en su lista: enlaces y reproducción, o temporadas. Es la reserva
    cuando Balandro no tiene el título en 1080p y castellano (plugin.py), mientras los enlaces de Palantir sigan."""
    title = _title(row)
    fields = {'label': title, 'tmdb': str(row['tmdb']), 'fecha': row.get('fecha'), 'plot': row.get('plot'),
              'poster': row.get('poster'), 'fanart': row.get('fondo'), 'clearlogo': row.get('clearlogo'),
              'mpaa': row.get('mpaa') or '',  # Palantir mira si lleva "+18"
              'rating': row.get('rating')}
    if kind == 'peliculas':
        fields.update(title=title, duration=row.get('duration'), action='selectvideos_', content='movies',
                      isPlayable=True)
    else:
        fields.update(tvshowtitle=title, action='listado_temporadaS', content='tvshows', page=0)
    return p3_url({k: v for k, v in fields.items() if v is not None})


def palantir_row(db_path, kind, tmdb):
    """La ficha del catálogo de Palantir si tiene enlaces, o None."""
    if not db_path or kind not in KINDS or not str(tmdb).isdigit():
        return None
    try:
        con = _read_only(db_path)
        try:
            linked = con.execute('SELECT 1 FROM %s WHERE tmdb = ? LIMIT 1' % KINDS[kind][1], (int(tmdb),)).fetchone()
        finally:
            con.close()
        rows = details(db_path, kind, [int(tmdb)]) if linked else []
    except sqlite3.Error:
        return None
    return rows[0] if rows else None


def links(db_path, kind, tmdb, season=None, episode=None):
    """Los enlaces del catálogo de una película o de un capítulo: [{link, calidad, audio}] ([] si no hay)."""
    if not db_path or kind not in KINDS or not str(tmdb).isdigit():
        return []
    sql = 'SELECT link, calidad, audio FROM %s WHERE tmdb = ?' % KINDS[kind][1]
    args = [int(tmdb)]
    if kind == 'series':
        sql += ' AND temporada = ? AND episodio = ?'
        args += [int(season or 1), int(episode or 1)]
    try:
        con = _read_only(db_path)
        try:
            return [{'link': l, 'calidad': c, 'audio': a} for l, c, a in con.execute(sql, args)]
        finally:
            con.close()
    except (sqlite3.Error, ValueError):
        return []


def episodes(db_path, tmdb):
    """{temporada: [capítulos]} de una serie del catálogo, por orden ({} si no está)."""
    if not db_path or not str(tmdb).isdigit():
        return {}
    try:
        con = _read_only(db_path)
        try:
            rows = con.execute('SELECT DISTINCT temporada, episodio FROM enlaces_series WHERE tmdb = ? '
                               'ORDER BY temporada, episodio', (int(tmdb),)).fetchall()
        finally:
            con.close()
    except sqlite3.Error:
        return {}
    out = {}
    for season, episode in rows:
        out.setdefault(int(season), []).append(int(episode))
    return out


def to_item(kind, row):
    """Elemento de la fila (forma de filas.to_item) para una película o serie de la base de Palantir: la película se
    reproduce al pulsarla y la serie abre sus temporadas, las dos por Balandro (fichas.py)."""
    movie = kind == 'peliculas'
    title = _title(row)
    fecha = row.get('fecha') or ''
    poster, fanart, logo = _image('w500', row.get('poster')), _image('w1280', row.get('fondo')), \
        _image('w500', row.get('clearlogo'))
    art = {'poster': poster, 'thumb': poster, 'fanart': fanart, 'clearlogo': logo}

    info = {'title': title, 'mediatype': 'movie' if movie else 'tvshow', 'plot': row.get('plot'),
            'mpaa': row.get('mpaa'), 'rating': _rating(row.get('rating'))}
    if fecha[:4].isdigit():
        info['year'], info['premiered'] = int(fecha[:4]), fecha
    if movie:
        info['duration'] = row.get('duration')
    genres = [g for g in (row.get('genero') or '').split('#') if g]
    if genres:
        info['genre'] = genres
    if row.get('trailer'):
        info['trailer'] = YOUTUBE % row['trailer']

    year = fecha[:4] if fecha[:4].isdigit() else ''
    path = play_url(kind, row['tmdb'], title, year) if movie else serie_url(row['tmdb'], title, year)
    return {'label': title, 'path': path, 'folder': not movie,
            'art': {k: v for k, v in art.items() if v}, 'info': {k: v for k, v in info.items() if v not in (None, '')},
            'uniqueids': {'tmdb': str(row['tmdb'])}, 'properties': {'IsPlayable': 'true'} if movie else {}}


# --- La base de Palantir (solo lectura) y nuestro índice de títulos ---

def _read_only(db_path):
    return sqlite3.connect('file:%s?mode=ro' % parse.quote(db_path), uri=True)


def stamp(db_path):
    """Fecha y tamaño de la base de Palantir: si cambian, se rehace el índice."""
    st = os.stat(db_path)
    return '%d-%d' % (int(st.st_mtime), st.st_size)


def build_index(db_path, index_path, db_stamp):
    """Títulos normalizados de lo que busca Palantir. Se escribe aparte y se cambia de golpe: las dos filas de la
    búsqueda se piden a la vez y ninguna debe leer un índice a medias."""
    src = _read_only(db_path)
    try:
        rows = []
        for kind, (table, links, categories) in KINDS.items():
            sql = 'SELECT tmdb, titulo FROM %s WHERE categoria IN (%s) AND tmdb IN (SELECT tmdb FROM %s)' % (
                table, ','.join('?' * len(categories)), links)
            rows += [(kind, tmdb, normalize(titulo)) for tmdb, titulo in src.execute(sql, categories)]
    finally:
        src.close()
    tmp = '%s.%s.tmp' % (index_path, os.urandom(4).hex())  # sin uuid: cada importación cuenta
    try:
        dst = sqlite3.connect(tmp)
        try:
            dst.execute('CREATE TABLE titulos (kind TEXT, tmdb INTEGER, norm TEXT)')
            dst.execute('CREATE TABLE meta (stamp TEXT)')
            dst.executemany('INSERT INTO titulos VALUES (?, ?, ?)', rows)
            dst.execute('INSERT INTO meta VALUES (?)', (db_stamp,))
            dst.commit()
        finally:
            dst.close()
        os.replace(tmp, index_path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def index_current(index_path, db_stamp):
    if not os.path.exists(index_path):
        return False
    try:
        con = sqlite3.connect(index_path)
        try:
            row = con.execute('SELECT stamp FROM meta').fetchone()
        finally:
            con.close()
    except sqlite3.Error:
        return False
    return bool(row) and row[0] == db_stamp


def search(index_path, kind, text, limit=LIMIT):
    """tmdb de los títulos que contienen el texto: primero los que empiezan por él, luego por orden alfabético."""
    query = normalize(text)  # sin % ni _: normalize quita los signos
    if len(query) < MIN_CHARS:
        return []
    con = sqlite3.connect(index_path)
    try:
        rows = con.execute(
            "SELECT tmdb FROM titulos WHERE kind = ? AND norm LIKE '%' || ? || '%' "
            "ORDER BY CASE WHEN norm LIKE ? || '%' THEN 0 ELSE 1 END, norm LIMIT ?",
            (kind, query, query, limit)).fetchall()
    finally:
        con.close()
    return [tmdb for tmdb, in rows]


def details(db_path, kind, tmdbs):
    """Las fichas de la base de Palantir, en el orden de tmdbs."""
    if not tmdbs:
        return []
    columns = FIELDS + (('duration',) if kind == 'peliculas' else ())
    con = _read_only(db_path)
    try:
        rows = con.execute('SELECT %s FROM %s WHERE tmdb IN (%s)' % (
            ', '.join(columns), KINDS[kind][0], ','.join('?' * len(tmdbs))), tmdbs).fetchall()
    finally:
        con.close()
    found = {row[0]: dict(zip(columns, row)) for row in rows}
    return [found[tmdb] for tmdb in tmdbs if tmdb in found]


def find(db_path, index_path, kind, text):
    """La fila de la búsqueda: elementos de to_item, o [] si no hay base, el tipo no existe o el texto es corto.
    Con ALL, las películas y luego las series."""
    if kind == ALL:
        return find(db_path, index_path, 'peliculas', text) + find(db_path, index_path, 'series', text)
    if not db_path or kind not in KINDS or len(normalize(text)) < MIN_CHARS:
        return []
    try:
        current = stamp(db_path)
        if not index_current(index_path, current):
            build_index(db_path, index_path, current)
        return [to_item(kind, row) for row in details(db_path, kind, search(index_path, kind, text))]
    except (OSError, sqlite3.Error):
        return []


class IndexKeeper(object):
    """Tiene el índice listo desde el servicio, para que la primera búsqueda no lo haga (en la caja ~2 s, y con las
    prisas de la primera búsqueda se hacía dos veces). db_path() da la ruta de la base de Palantir o None."""
    START_DELAY = 60  # s: deja arrancar a Kodi
    CHECK_EVERY = 600  # s: Palantir casi nunca cambia su base

    def __init__(self, db_path, index_path, clock):
        self.db_path, self.index_path, self.clock = db_path, index_path, clock
        self.next_check = clock() + self.START_DELAY

    def tick(self):
        now = self.clock()
        if now < self.next_check:
            return None
        self.next_check = now + self.CHECK_EVERY
        db = self.db_path()
        if not db:
            return None
        current = stamp(db)
        if index_current(self.index_path, current):
            return None
        build_index(db, self.index_path, current)
        return 'índice del catálogo de Palantir rehecho'
